﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабараторная_работа__4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void черныйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtA.BackColor = System.Drawing.Color.Black;
        }

        private void красныйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtA.BackColor = System.Drawing.Color.Red;
        }

        private void синийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtA.BackColor = System.Drawing.Color.Blue;
        }

        private void желтыйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtA.BackColor = System.Drawing.Color.Yellow;
        }

        private void голубойToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtA.BackColor = System.Drawing.Color.Aqua;
        }

        private void bmwToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
