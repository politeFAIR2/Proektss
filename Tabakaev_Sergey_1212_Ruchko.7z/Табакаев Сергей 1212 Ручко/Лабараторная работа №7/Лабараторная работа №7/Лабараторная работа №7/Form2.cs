﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабараторная_работа__7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.Text = "Работа с текстом";


            lb1.Text = "Операции с текстом";
            lb1.BackColor = Color.White;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem.Text)
            {
                case "Красный фон метки":
                    lb1.BackColor = Color.Red;
                    break;
                case "Зеленый фон формы":
                    this.BackColor = Color.Green;
                    break;
                case "Белый текст метки":
                    lb1.ForeColor = Color.White;
                    break;
            }
        }
    }
}
