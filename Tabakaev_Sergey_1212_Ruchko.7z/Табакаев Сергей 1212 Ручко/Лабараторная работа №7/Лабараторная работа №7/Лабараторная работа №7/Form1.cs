﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабараторная_работа__7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Text = "Работа с текстом";

            lb1.Text = "Операции с текстом";
            lb1.BackColor = Color.White;

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            lb1.BackColor = Color.Red;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            lb1.BackColor = Color.Black;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            lb1.BackColor = Color.Blue;
        }
    }
}
