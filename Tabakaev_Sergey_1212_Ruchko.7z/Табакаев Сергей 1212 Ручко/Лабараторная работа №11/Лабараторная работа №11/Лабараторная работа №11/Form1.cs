﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Лабараторная_работа__11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnA_Click(object sender, EventArgs e)
        {
            string input = txtArray.Text;
            if (string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Пожалуйста, введите числа, разделенные пробелами.");
                return;
            }
            string[] numbers = input.Split(' ');
            double[] array = new double[numbers.Length];
            for (int i = 0; i < numbers.Length; i++)
            {
                if (!double.TryParse(numbers[i], out array[i]))
                {
                    MessageBox.Show("Некорректный ввод. Проверьте, что все значения являются числами.");
                    return;
                }
            }
            double sum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                sum += array[i];
            }
            double average = sum / array.Length;
            txtSum.Text = sum.ToString();
            txtAverage.Text = average.ToString();
        }
    }
}
