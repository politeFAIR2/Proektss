﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабаратораня_работа__8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double Precision;

        private void btn1_Click(object sender, EventArgs e)
        {
            int counter = 0;
            double sum = 0;
            double summand = 0.0;
            double x;
            bool f = false;
            if (double.TryParse(txtPrecision.Text, out Precision))
            {
                f = true;
                do
                {
                    counter++;
                    if (double.TryParse(txtX.Text, out x))
                    {
                        summand = x / counter;
                    }
                    sum += summand;
                }
                while (f && Math.Abs(summand) > Precision);
                lblResult.Text = "Сумма = " + sum + ", количество = " + counter;
                if (f)
                {
                    lblResult.Text = "сумма = " + ", количество = " + counter;

                }
                else
                {
                    MessageBox.Show("Введите числовое значение!");
                }
            }
        }
    }
}
