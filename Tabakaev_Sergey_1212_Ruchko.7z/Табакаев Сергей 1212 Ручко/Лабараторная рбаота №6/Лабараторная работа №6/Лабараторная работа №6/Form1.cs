﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабараторная_работа__6
{
    public partial class Form1 : Form
    {
        private int seconds = 0;
        private int minutes = 0;
        private bool isRunning = false;
        public Form1()
        {
            InitializeComponent();
    }

        private void btnA_Click(object sender, EventArgs e)
        {
            if (!isRunning)
            {
                timer1.Enabled = true;
                isRunning = true;
                btnA.Text = "Пауза";
            }
            else
            {
                timer1.Enabled = false;
                isRunning = false;
                btnA.Text = "Старт";
            }
        }
    

        private void timer1_Tick(object sender, EventArgs e)
        {
             seconds ++;

            txtA.Text = seconds.ToString();


            if (seconds >= 60)
            {
                minutes++;
                seconds = 0;

                txtA.Text = seconds.ToString("D2");
                txtB.Text = minutes.ToString("D2");
            }
        }

        private void btnB_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            isRunning = false;
            seconds = 0;
            minutes = 0;
            btnA.Text = "Старт";
            txtA.Text = "00";
            txtB.Text = "00";
        }
    }
}
