﻿namespace Лабараторная_работа__5
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstResult = new System.Windows.Forms.ListBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtD = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.btnABCD = new System.Windows.Forms.Button();
            this.fromX = new System.Windows.Forms.Label();
            this.toX = new System.Windows.Forms.Label();
            this.fromY = new System.Windows.Forms.Label();
            this.toY = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstResult
            // 
            this.lstResult.FormattingEnabled = true;
            this.lstResult.ItemHeight = 25;
            this.lstResult.Location = new System.Drawing.Point(490, 234);
            this.lstResult.Name = "lstResult";
            this.lstResult.Size = new System.Drawing.Size(292, 204);
            this.lstResult.TabIndex = 0;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(490, 57);
            this.txtB.Multiline = true;
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(206, 38);
            this.txtB.TabIndex = 1;
            // 
            // txtD
            // 
            this.txtD.Location = new System.Drawing.Point(490, 176);
            this.txtD.Multiline = true;
            this.txtD.Name = "txtD";
            this.txtD.Size = new System.Drawing.Size(206, 37);
            this.txtD.TabIndex = 2;
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(90, 176);
            this.txtC.Multiline = true;
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(201, 37);
            this.txtC.TabIndex = 3;
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(90, 57);
            this.txtA.Multiline = true;
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(201, 38);
            this.txtA.TabIndex = 4;
            // 
            // btnABCD
            // 
            this.btnABCD.Location = new System.Drawing.Point(28, 386);
            this.btnABCD.Name = "btnABCD";
            this.btnABCD.Size = new System.Drawing.Size(250, 52);
            this.btnABCD.TabIndex = 5;
            this.btnABCD.Text = "Calculate z(x,y)";
            this.btnABCD.UseVisualStyleBackColor = true;
            this.btnABCD.Click += new System.EventHandler(this.btnABCD_Click);
            // 
            // fromX
            // 
            this.fromX.AutoSize = true;
            this.fromX.Location = new System.Drawing.Point(12, 70);
            this.fromX.Name = "fromX";
            this.fromX.Size = new System.Drawing.Size(60, 25);
            this.fromX.TabIndex = 6;
            this.fromX.Text = "from:";
            // 
            // toX
            // 
            this.toX.AutoSize = true;
            this.toX.Location = new System.Drawing.Point(394, 70);
            this.toX.Name = "toX";
            this.toX.Size = new System.Drawing.Size(36, 25);
            this.toX.TabIndex = 7;
            this.toX.Text = "to:";
            // 
            // fromY
            // 
            this.fromY.AutoSize = true;
            this.fromY.Location = new System.Drawing.Point(12, 188);
            this.fromY.Name = "fromY";
            this.fromY.Size = new System.Drawing.Size(60, 25);
            this.fromY.TabIndex = 8;
            this.fromY.Text = "from:";
            // 
            // toY
            // 
            this.toY.AutoSize = true;
            this.toY.Location = new System.Drawing.Point(394, 188);
            this.toY.Name = "toY";
            this.toY.Size = new System.Drawing.Size(36, 25);
            this.toY.TabIndex = 9;
            this.toY.Text = "to:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "x range";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.toY);
            this.Controls.Add(this.fromY);
            this.Controls.Add(this.toX);
            this.Controls.Add(this.fromX);
            this.Controls.Add(this.btnABCD);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtD);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.lstResult);
            this.Name = "Form1";
            this.Text = "for loops";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstResult;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Button btnABCD;
        private System.Windows.Forms.Label fromX;
        private System.Windows.Forms.Label toX;
        private System.Windows.Forms.Label fromY;
        private System.Windows.Forms.Label toY;
        private System.Windows.Forms.Label label5;
    }
}

