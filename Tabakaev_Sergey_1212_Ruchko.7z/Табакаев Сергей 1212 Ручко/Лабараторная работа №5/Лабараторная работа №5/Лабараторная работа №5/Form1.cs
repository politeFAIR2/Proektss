﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабараторная_работа__5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnABCD_Click(object sender, EventArgs e)
        {
            int fromX = int.Parse(txtA.Text);
            int toX = int.Parse(txtB.Text);
            int fromY = int.Parse(txtC.Text);
            int toY= int.Parse(txtD.Text);
            for (int x = fromX; x <= toX; x++)
            {
                for (int y = fromY; y <= toY; y++)
                {
                    lstResult.Items.Add($"z(x,y) = {x} - {y} = {x - y}");
                }
            }
            if (fromX > toX)
            {
                MessageBox.Show("Интеравал должен быть от меньшему к большему");
                txtA.Text = "";
                txtC.Text = "";
            }
        }
    }
}
