﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабараторная_работа__2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lst_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lst.SelectedItem == "BMW")
            {
                txtA.BackColor = System.Drawing.Color.Black;
            }
            else if (lst.SelectedItem == "AUDI")
            {
                txtA.BackColor= System.Drawing.Color.Red;
            }
            else if(lst.SelectedItem == "LADA")
            {
                txtA.BackColor = System.Drawing.Color.Green;
            }
            else if (lst.SelectedItem == "TOYOTA") 
            {
                txtA.BackColor = System.Drawing.Color.Blue;
            }
            else if (lst.SelectedItem == "NISSAN")
            {
                txtA.BackColor = System.Drawing.Color.Gray;
            }
            else if (lst.SelectedItem == "KIA")
            {
                txtA.BackColor = System.Drawing.Color.Aqua;
            }
        }
    }
}
