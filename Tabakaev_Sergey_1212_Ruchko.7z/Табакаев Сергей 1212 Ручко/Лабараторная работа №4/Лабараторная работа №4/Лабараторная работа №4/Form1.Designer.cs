﻿namespace Лабараторная_работа__4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnZakaz = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lstB = new System.Windows.Forms.ListBox();
            this.lstA = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnZakaz
            // 
            this.btnZakaz.Location = new System.Drawing.Point(554, 382);
            this.btnZakaz.Name = "btnZakaz";
            this.btnZakaz.Size = new System.Drawing.Size(166, 56);
            this.btnZakaz.TabIndex = 0;
            this.btnZakaz.Text = "Заказать";
            this.btnZakaz.UseVisualStyleBackColor = true;
            this.btnZakaz.Click += new System.EventHandler(this.btnZakaz_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(349, 92);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(132, 64);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(349, 291);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(132, 80);
            this.btnRemove.TabIndex = 2;
            this.btnRemove.Text = "Удалить";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lstB
            // 
            this.lstB.FormattingEnabled = true;
            this.lstB.ItemHeight = 25;
            this.lstB.Location = new System.Drawing.Point(507, 71);
            this.lstB.Name = "lstB";
            this.lstB.Size = new System.Drawing.Size(248, 279);
            this.lstB.TabIndex = 3;
            // 
            // lstA
            // 
            this.lstA.FormattingEnabled = true;
            this.lstA.ItemHeight = 25;
            this.lstA.Items.AddRange(new object[] {
            "Жаренный гусь",
            "Жаренная картошка ",
            "Салат Оливье",
            "Кампот",
            "Глазунья ",
            "Итальянский завтрак",
            "Паста",
            "Стейк из говядины",
            "Стейк из свинины",
            "Шашлык",
            "Жаркое",
            "Вареники ",
            "Пельмени"});
            this.lstA.Location = new System.Drawing.Point(38, 92);
            this.lstA.Name = "lstA";
            this.lstA.Size = new System.Drawing.Size(272, 279);
            this.lstA.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstA);
            this.Controls.Add(this.lstB);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnZakaz);
            this.Name = "Form1";
            this.Text = "Ресторан \"IBIR\"";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnZakaz;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ListBox lstB;
        private System.Windows.Forms.ListBox lstA;
    }
}

