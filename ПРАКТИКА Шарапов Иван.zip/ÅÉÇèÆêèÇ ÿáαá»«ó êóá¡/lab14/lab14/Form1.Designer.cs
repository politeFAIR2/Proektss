﻿namespace lab14
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtN = new TextBox();
            txtMin = new TextBox();
            txtMax = new TextBox();
            lblArr = new Label();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            lblResult = new Label();
            btnNewArr = new Button();
            btnSort = new Button();
            btnExit = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(111, 61);
            label1.Name = "label1";
            label1.Size = new Size(166, 15);
            label1.TabIndex = 0;
            label1.Text = "Количество чисел в массиве";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(111, 94);
            label2.Name = "label2";
            label2.Size = new Size(135, 15);
            label2.TabIndex = 1;
            label2.Text = "Нижняя граница чисел";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(111, 127);
            label3.Name = "label3";
            label3.Size = new Size(136, 15);
            label3.TabIndex = 2;
            label3.Text = "Верхняя граница чисел";
            // 
            // txtN
            // 
            txtN.Location = new Point(283, 61);
            txtN.Name = "txtN";
            txtN.Size = new Size(100, 23);
            txtN.TabIndex = 3;
            // 
            // txtMin
            // 
            txtMin.Location = new Point(283, 94);
            txtMin.Name = "txtMin";
            txtMin.Size = new Size(100, 23);
            txtMin.TabIndex = 4;
            txtMin.TextChanged += txtMin_TextChanged;
            // 
            // txtMax
            // 
            txtMax.Location = new Point(283, 127);
            txtMax.Name = "txtMax";
            txtMax.Size = new Size(100, 23);
            txtMax.TabIndex = 5;
            txtMax.TextChanged += txtMax_TextChanged;
            // 
            // lblArr
            // 
            lblArr.AutoSize = true;
            lblArr.Location = new Point(6, 32);
            lblArr.Name = "lblArr";
            lblArr.Size = new Size(0, 15);
            lblArr.TabIndex = 6;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblArr);
            groupBox1.Location = new Point(111, 214);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(502, 50);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Исходный массив";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblResult);
            groupBox2.Location = new Point(111, 295);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(502, 50);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Преобразованный массив";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(6, 32);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(0, 15);
            lblResult.TabIndex = 6;
            // 
            // btnNewArr
            // 
            btnNewArr.Location = new Point(134, 399);
            btnNewArr.Name = "btnNewArr";
            btnNewArr.Size = new Size(113, 23);
            btnNewArr.TabIndex = 10;
            btnNewArr.Text = "Новый массив";
            btnNewArr.UseVisualStyleBackColor = true;
            btnNewArr.Click += btnNewArr_Click;
            // 
            // btnSort
            // 
            btnSort.Location = new Point(253, 399);
            btnSort.Name = "btnSort";
            btnSort.Size = new Size(105, 23);
            btnSort.TabIndex = 11;
            btnSort.Text = "Сортировать";
            btnSort.UseVisualStyleBackColor = true;
            btnSort.Click += btnSort_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(364, 399);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(106, 23);
            btnExit.TabIndex = 12;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(553, 450);
            Controls.Add(btnExit);
            Controls.Add(btnSort);
            Controls.Add(btnNewArr);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(txtMax);
            Controls.Add(txtMin);
            Controls.Add(txtN);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtN;
        private TextBox txtMin;
        private TextBox txtMax;
        private Label lblArr;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label lblResult;
        private Button btnNewArr;
        private Button btnSort;
        private Button btnExit;
    }
}
