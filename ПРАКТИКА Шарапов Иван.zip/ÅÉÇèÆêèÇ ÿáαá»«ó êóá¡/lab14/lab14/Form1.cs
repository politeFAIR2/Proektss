namespace lab14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int[] arr = new int[10];
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void ClearFields()
        {
            lblArr.Text = "";
            lblResult.Text = "";
            btnSort.Enabled = false;
        }
        private void btnNewArr_Click(object sender, EventArgs e)
        {
            ClearFields();

            Random rnd = new Random();

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rnd.Next(int.Parse(txtMin.Text), int.Parse(txtMax.Text) + 1);
            }

            lblArr.Text = "�������� ������: " + string.Join(", ", arr);
            btnSort.Enabled = true;
        }
        private int MinNumber(int[] arr, int start)
        {
            int minIndex = start;

            for (int i = start + 1; i < arr.Length; i++)
            {
                if (arr[i] < arr[minIndex])
                {
                    minIndex = i;
                }
            }

            return minIndex;
        }
        private void txtMin_TextChanged(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int minIndex = MinNumber(arr, i);

                if (minIndex != i)
                {
                    int temp = arr[i];
                    arr[i] = arr[minIndex];
                    arr[minIndex] = temp;
                }
            }

            lblResult.Text = "��������������� ������: " + string.Join(", ", arr);
        }

        private void txtMax_TextChanged(object sender, EventArgs e)
        {
            ClearFields();
        }
    }
}
