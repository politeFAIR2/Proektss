namespace lab12
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void frm1_Click(object sender, EventArgs e)
        {
            frm1 frm = new frm1();
            frm.Show();
        }

        private void Frm2_Click(object sender, EventArgs e)
        {
            frm2 frm = new frm2();
            frm.Show();
        }

        private void Frm3_Click(object sender, EventArgs e)
        {
            frm3 frm = new frm3();
            frm.Show();
        }

        private void �����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
