﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab4
{
    public partial class РЕсторан : Form
    {
        public РЕсторан()
        {
            InitializeComponent();
            lstMenu.Items.Add("плов");
            lstMenu.Items.Add("Манты");
            lstMenu.Items.Add("тушеная капуста");
            lstMenu.Items.Add("кофе");

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lstZakaz.Items.Add(lstMenu.Text);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            lstZakaz.Items.Remove(lstZakaz.SelectedItem);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Приятного аппетита!", "Ресторан студент");
            this.Close();
        }

        private void lstZakaz_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
