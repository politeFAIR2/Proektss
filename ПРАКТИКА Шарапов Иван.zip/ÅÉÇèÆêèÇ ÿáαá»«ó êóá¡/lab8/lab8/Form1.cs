﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            
            int numb;

           
            if (int.TryParse(txtInput.Text, out numb))
            {
          
                if (numb < 0)
                {
                    MessageBox.Show("Введите неотрицательное число.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    long factorial = FactorialClass.Factorial(numb);

                    txtFactorial.Text = factorial.ToString();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректное целое число.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}