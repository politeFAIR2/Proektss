﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }       
        private void Form1_Load_1(object sender, EventArgs e)
        {
            lst.Items.Add("черный");
            lst.Items.Add("красный");
            lst.Items.Add("синий");
            lst.Items.Add("зеленый");
        }

        private void lst_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedColor = lst.SelectedItem.ToString();
            txt.Text = selectedColor;


            switch (selectedColor)
            {
                case "черный":
                    txt.BackColor = Color.Black;
                    txt.ForeColor = Color.White;
                    break;
                case "красный":
                    txt.BackColor = Color.Red;
                    txt.ForeColor = Color.White;
                    break;
                case "синий":
                    txt.BackColor = Color.Blue;
                    txt.ForeColor = Color.White;
                    break;
                case "зеленый":
                    txt.BackColor = Color.Green;
                    txt.ForeColor = Color.White;
                    break;
                default:
                    txt.BackColor = SystemColors.Window;
                    txt.ForeColor = SystemColors.WindowText;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
