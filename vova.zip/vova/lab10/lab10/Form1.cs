﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblAverage_Click(object sender, EventArgs e)
        {

        }
        

        private void btnCalculate_Click_1(object sender, EventArgs e)
        {
            // Получаем числа из TextBox
            string[] numbersString = textBox1.Text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            // Преобразование строк в числа
            int[] numbers = new int[numbersString.Length];
            for (int i = 0; i < numbersString.Length; i++)
            {
                numbers[i] = int.Parse(numbersString[i]);
            }

            // Подсчет суммы
            int sum = 0;
            foreach (int number in numbers)
            {
                sum += number;
            }

            // Подсчет среднего арифметического
            double average = (double)sum / numbers.Length;

            // Вывод результатов в Label
            label2.Text = "Sum: " + sum;
            lblAverage.Text = "Average: " + average.ToString("N2"); // Округление до двух знаков после запятой
        }
    }
}
