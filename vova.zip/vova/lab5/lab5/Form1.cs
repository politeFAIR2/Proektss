﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {
            try
            {
                int x1 = int.Parse(txtX1.Text);
                int x2 = int.Parse(txtX2.Text);
                int y1 = int.Parse(txtY1.Text);
                int y2 = int.Parse(txtY2.Text);

                lstResult.Items.Clear();
                for (int x = x1; x <= x2; x++)
                {
                    for (int y = y1; y <= y2; y++)
                    {
                        
                        int z = x * y;  

                        
                        lstResult.Items.Add($"x = {x}, y = {y}, z = {z}");
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Пожалуйста, введите корректные значения!", "Ошибка ввода");
            }
        }
    }
    }

