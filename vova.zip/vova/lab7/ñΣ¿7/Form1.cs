﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace дфи7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
               
                double x = double.Parse(txtX.Text);
                double precision = double.Parse(txtPrecision.Text);

              
                if (Math.Abs(x) >= 1)
                {
                    MessageBox.Show("Значение x должно быть в пределах |x| < 1", "Ошибка");
                    return;
                }
                double sum = 0;
                int termCount = 0;
                double term = x; 
               
                while (Math.Abs(term) >= precision)
                {
                    sum += term;
                    termCount++;
                    term = x / (termCount + 1); 
                }
                lblResult.Text = $"Сумма ряда: {sum}\nКоличество слагаемых: {termCount}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Пожалуйста, введите корректные значения!", "Ошибка");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    
    }

