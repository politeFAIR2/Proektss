﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            string inputString = txtInput.Text; // Получение текста из текстового поля
            int count = CountLetterA(inputString); // Вызов функции для подсчета букв 'а'
            lblResult.Text = $"Количество букв 'а': {count}"; // Вывод результата в метку
        }

        // Функция для подсчета букв "а" в строке
        private int CountLetterA(string text)
        {
            int count = 0;
            foreach (char letter in text.ToLower()) // Преобразуем строку в нижний регистр для точного подсчета
            {
                if (letter == 'а')
                {
                    count++;
                }
            }
            return count;
        }
    }
}
