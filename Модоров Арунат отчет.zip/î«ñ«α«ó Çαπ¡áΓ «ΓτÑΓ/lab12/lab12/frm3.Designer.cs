﻿namespace lab12
{
    partial class frm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnu = new System.Windows.Forms.MenuStrip();
            this.лабораторнаяРаботаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.главнаяФормаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.форма1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnu
            // 
            this.mnu.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.mnu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.лабораторнаяРаботаToolStripMenuItem});
            this.mnu.Location = new System.Drawing.Point(0, 0);
            this.mnu.Name = "mnu";
            this.mnu.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.mnu.Size = new System.Drawing.Size(221, 24);
            this.mnu.TabIndex = 0;
            this.mnu.Text = "menuStrip1";
            // 
            // лабораторнаяРаботаToolStripMenuItem
            // 
            this.лабораторнаяРаботаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.главнаяФормаToolStripMenuItem,
            this.форма1ToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.лабораторнаяРаботаToolStripMenuItem.Name = "лабораторнаяРаботаToolStripMenuItem";
            this.лабораторнаяРаботаToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.лабораторнаяРаботаToolStripMenuItem.Text = "Лабораторная работа";
            // 
            // главнаяФормаToolStripMenuItem
            // 
            this.главнаяФормаToolStripMenuItem.Name = "главнаяФормаToolStripMenuItem";
            this.главнаяФормаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.главнаяФормаToolStripMenuItem.Text = "Главная форма";
            this.главнаяФормаToolStripMenuItem.Click += new System.EventHandler(this.главнаяФормаToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(50, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // форма1ToolStripMenuItem
            // 
            this.форма1ToolStripMenuItem.Name = "форма1ToolStripMenuItem";
            this.форма1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.форма1ToolStripMenuItem.Text = "форма 1";
            this.форма1ToolStripMenuItem.Click += new System.EventHandler(this.форма1ToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // frm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(221, 234);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.mnu);
            this.MainMenuStrip = this.mnu;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frm3";
            this.Text = "frm3";
            this.mnu.ResumeLayout(false);
            this.mnu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnu;
        private System.Windows.Forms.ToolStripMenuItem лабораторнаяРаботаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem главнаяФормаToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem форма1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
    }
}