﻿namespace lab12
{
    partial class frm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnu = new System.Windows.Forms.MenuStrip();
            this.лабораторнаяРаботаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmMainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frm3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.mnu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnu
            // 
            this.mnu.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.mnu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.лабораторнаяРаботаToolStripMenuItem});
            this.mnu.Location = new System.Drawing.Point(0, 0);
            this.mnu.Name = "mnu";
            this.mnu.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.mnu.Size = new System.Drawing.Size(229, 24);
            this.mnu.TabIndex = 0;
            this.mnu.Text = "menuStrip1";
            // 
            // лабораторнаяРаботаToolStripMenuItem
            // 
            this.лабораторнаяРаботаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmMainToolStripMenuItem,
            this.frm3ToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.лабораторнаяРаботаToolStripMenuItem.Name = "лабораторнаяРаботаToolStripMenuItem";
            this.лабораторнаяРаботаToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.лабораторнаяРаботаToolStripMenuItem.Text = "Лабораторная работа";
            // 
            // frmMainToolStripMenuItem
            // 
            this.frmMainToolStripMenuItem.Name = "frmMainToolStripMenuItem";
            this.frmMainToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.frmMainToolStripMenuItem.Text = "Главная форма";
            this.frmMainToolStripMenuItem.Click += new System.EventHandler(this.frmMainToolStripMenuItem_Click);
            // 
            // frm3ToolStripMenuItem
            // 
            this.frm3ToolStripMenuItem.Name = "frm3ToolStripMenuItem";
            this.frm3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.frm3ToolStripMenuItem.Text = "Форма 2";
            this.frm3ToolStripMenuItem.Click += new System.EventHandler(this.frm3ToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Страница 2";
            // 
            // frm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 234);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mnu);
            this.MainMenuStrip = this.mnu;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frm2";
            this.Text = "frm2";
            this.mnu.ResumeLayout(false);
            this.mnu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnu;
        private System.Windows.Forms.ToolStripMenuItem лабораторнаяРаботаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmMainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frm3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}