﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab12
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void frmMainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm2 newForm2 = new frm2();
            newForm2.Show();
        }

        private void frmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm3 newForm3 = new frm3();
            newForm3.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
