﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab12
{
    public partial class frm3 : Form
    {
        public frm3()
        {
            InitializeComponent();
        }

        private void frmMainToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void главнаяФормаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMain newForm1 = new frmMain();
            newForm1.Show();
        }
        private void форма1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm2 newForm2 = new frm2();
            newForm2.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
