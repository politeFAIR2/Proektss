﻿namespace lab12
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnu = new System.Windows.Forms.MenuStrip();
            this.лабораторнаяРаботаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmMainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnu
            // 
            this.mnu.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.mnu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.лабораторнаяРаботаToolStripMenuItem});
            this.mnu.Location = new System.Drawing.Point(0, 0);
            this.mnu.Name = "mnu";
            this.mnu.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.mnu.Size = new System.Drawing.Size(199, 24);
            this.mnu.TabIndex = 0;
            this.mnu.Text = "menuStrip1";
            // 
            // лабораторнаяРаботаToolStripMenuItem
            // 
            this.лабораторнаяРаботаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmMainToolStripMenuItem,
            this.frmToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.лабораторнаяРаботаToolStripMenuItem.Name = "лабораторнаяРаботаToolStripMenuItem";
            this.лабораторнаяРаботаToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.лабораторнаяРаботаToolStripMenuItem.Text = "Лабораторная работа";
            // 
            // frmMainToolStripMenuItem
            // 
            this.frmMainToolStripMenuItem.Name = "frmMainToolStripMenuItem";
            this.frmMainToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.frmMainToolStripMenuItem.Text = "форма 1";
            this.frmMainToolStripMenuItem.Click += new System.EventHandler(this.frmMainToolStripMenuItem_Click);
            // 
            // frmToolStripMenuItem
            // 
            this.frmToolStripMenuItem.Name = "frmToolStripMenuItem";
            this.frmToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.frmToolStripMenuItem.Text = "Форма 2";
            this.frmToolStripMenuItem.Click += new System.EventHandler(this.frmToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(199, 234);
            this.Controls.Add(this.mnu);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMain";
            this.Text = "Form1";
            this.mnu.ResumeLayout(false);
            this.mnu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnu;
        private System.Windows.Forms.ToolStripMenuItem лабораторнаяРаботаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmMainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
    }
}

