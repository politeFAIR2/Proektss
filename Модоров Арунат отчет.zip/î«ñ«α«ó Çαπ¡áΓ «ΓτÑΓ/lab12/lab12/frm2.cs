﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab12
{
    public partial class frm2 : Form
    {
        public frm2()
        {
            InitializeComponent();
        }

        private void frmMainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMain newFomr1 = new frmMain();
            newFomr1.Show();
        }
        private void frm3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm3 newForm3 = new frm3();
            newForm3.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
