﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int counter = 0;
            double sum = 0;
            double summand = 0.0;
            double x;
            do
            {
                counter++;
                if (double.TryParse(txtX.Text, out x))
                {
                    summand = x / counter;
                }
                sum += summand;
            }while(Math.Abs(summand) > double.Parse(txtPrecision.Text));
                if (f)
                {
                    lblResult.Text = "сумма = " + sum + ",количество =  " + counter;
                }
                else
                {
                    MessageBox.Show("Введите числовое значение");
                }
            }
  

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
