﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCaunt_Click(object sender, EventArgs e)
        {
            string inputString = txtInput.Text;
            int count = NumberSymbols(inputString, 'а');
            txtResult.Text = $"{count}";
        }

        private int NumberSymbols(string input, char symbol)
        {
            int count = 0;
            foreach (char c in input)
            {
                if (c == symbol)
                {
                    count++;
                }
            }
            return count;
        }

    }
    
}
