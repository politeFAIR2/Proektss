﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private long Factorial(int n)
        {
            long p = 2;
            for (int i = 3; i <= n; i++)
                p = p * i;
            return p;

        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            int numb;
            if (int.TryParse(txt1.Text, out numb))
            {
                txtFactorial.Text = Factorial(numb).ToString();
            }
            else
                MessageBox.Show("Ввидите число");
        }
    }
}
