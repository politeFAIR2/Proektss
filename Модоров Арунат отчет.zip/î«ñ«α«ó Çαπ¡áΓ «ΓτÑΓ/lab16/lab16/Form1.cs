﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab16
{
    public partial class Form1 : Form
    {
        private bool КнопкаНажата = false;
        private Color myb = Color.Red; // Цвет фигуры
        private int size = 10; // Размер фигуры
        private bool drawSquare = false; // Флаг для рисования квадрата
        private bool drawEllipse = false; // Флаг для рисования эллипса

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (КнопкаНажата)
            {
                Graphics g = CreateGraphics();
                if (drawSquare)
                {
                    // Рисуем квадрат
                    g.FillRectangle(new SolidBrush(myb), e.X - size / 2, e.Y - size / 2, size, size);
                }
                else if (drawEllipse)
                {
                    // Рисуем эллипс
                    g.FillEllipse(new SolidBrush(myb), e.X - size / 2, e.Y - size / 2, size, size);
                }
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                КнопкаНажата = true;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                КнопкаНажата = false;
            }
        }
        private void инструментКвадратToolStripMenuItem_Click(object sender, EventArgs e)
        {
            drawSquare = true;
            drawEllipse = false;
        }

        private void инструментЭллипсToolStripMenuItem_Click(object sender, EventArgs e)
        {
            drawSquare = false;
            drawEllipse = true;
        }
    }
}

