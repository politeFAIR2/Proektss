﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btcCalc_Click(object sender, EventArgs e)
        {
          
            int size = 10; 
            int[] array = new int[size];

          
            Random random = new Random();
            for (int i = 0; i < size; i++)
            {
                array[i] = random.Next(1, 101); 
            }

          
            txtArray.Text = string.Join(", ", array);

           
            int sum = array.Sum();
            double average = (double)sum / size;

           
            txtSum.Text = sum.ToString();
            txtAverage.Text = average.ToString("F2"); 



        }

    }
}
