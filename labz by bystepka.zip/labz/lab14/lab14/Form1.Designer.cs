﻿
namespace lab14
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNum = new System.Windows.Forms.TextBox();
            this.txtMin = new System.Windows.Forms.TextBox();
            this.txtMax = new System.Windows.Forms.TextBox();
            this.lblArray = new System.Windows.Forms.Label();
            this.lblSortArray = new System.Windows.Forms.Label();
            this.btnNewAr = new System.Windows.Forms.Button();
            this.btnSort = new System.Windows.Forms.Button();
            this.ext = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(220, 51);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(100, 20);
            this.txtNum.TabIndex = 0;
            // 
            // txtMin
            // 
            this.txtMin.Location = new System.Drawing.Point(220, 94);
            this.txtMin.Name = "txtMin";
            this.txtMin.Size = new System.Drawing.Size(100, 20);
            this.txtMin.TabIndex = 1;
            // 
            // txtMax
            // 
            this.txtMax.Location = new System.Drawing.Point(220, 135);
            this.txtMax.Name = "txtMax";
            this.txtMax.Size = new System.Drawing.Size(100, 20);
            this.txtMax.TabIndex = 2;
            // 
            // lblArray
            // 
            this.lblArray.AutoSize = true;
            this.lblArray.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblArray.Location = new System.Drawing.Point(220, 214);
            this.lblArray.Name = "lblArray";
            this.lblArray.Size = new System.Drawing.Size(2, 15);
            this.lblArray.TabIndex = 3;
            // 
            // lblSortArray
            // 
            this.lblSortArray.AutoSize = true;
            this.lblSortArray.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSortArray.Location = new System.Drawing.Point(223, 271);
            this.lblSortArray.Name = "lblSortArray";
            this.lblSortArray.Size = new System.Drawing.Size(2, 15);
            this.lblSortArray.TabIndex = 4;
            // 
            // btnNewAr
            // 
            this.btnNewAr.Location = new System.Drawing.Point(75, 371);
            this.btnNewAr.Name = "btnNewAr";
            this.btnNewAr.Size = new System.Drawing.Size(98, 38);
            this.btnNewAr.TabIndex = 5;
            this.btnNewAr.Text = "Новый массив";
            this.btnNewAr.UseVisualStyleBackColor = true;
            this.btnNewAr.Click += new System.EventHandler(this.btnNewAr_Click);
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(179, 371);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(99, 39);
            this.btnSort.TabIndex = 6;
            this.btnSort.Text = "Сортировать";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // ext
            // 
            this.ext.Location = new System.Drawing.Point(284, 371);
            this.ext.Name = "ext";
            this.ext.Size = new System.Drawing.Size(99, 39);
            this.ext.TabIndex = 7;
            this.ext.Text = "выйти";
            this.ext.UseVisualStyleBackColor = true;
            this.ext.Click += new System.EventHandler(this.ext_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Кол-во чисел";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Нижняя граница";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(123, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Верхняя граница";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ext);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.btnNewAr);
            this.Controls.Add(this.lblSortArray);
            this.Controls.Add(this.lblArray);
            this.Controls.Add(this.txtMax);
            this.Controls.Add(this.txtMin);
            this.Controls.Add(this.txtNum);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.TextBox txtMin;
        private System.Windows.Forms.TextBox txtMax;
        private System.Windows.Forms.Label lblArray;
        private System.Windows.Forms.Label lblSortArray;
        private System.Windows.Forms.Button btnNewAr;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.Button ext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

