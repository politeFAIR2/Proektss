﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab14
{
    public partial class Form1 : Form
    {
        private int[] array;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnNewAr_Click(object sender, EventArgs e)
        {
            int n = int.Parse(txtNum.Text); 
            int min = int.Parse(txtMin.Text); 
            int max = int.Parse(txtMax.Text);
            Random rnd = new Random();
            array = new int[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = rnd.Next(min, max);
            }
            lblArray.Text = string.Join(", ", array);
            btnSort.Enabled = true; 
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            Array.Sort(array);
            lblSortArray.Text = string.Join(", ", array);
            btnSort.Enabled = false;
        }

        private void ext_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
