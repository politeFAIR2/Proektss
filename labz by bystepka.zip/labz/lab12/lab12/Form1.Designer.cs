﻿namespace lab12
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnu = new System.Windows.Forms.ToolStripMenuItem();
            this.frm1 = new System.Windows.Forms.ToolStripMenuItem();
            this.frm2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ext = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(465, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnu
            // 
            this.mnu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frm1,
            this.frm2,
            this.toolStripSeparator1,
            this.ext});
            this.mnu.Name = "mnu";
            this.mnu.Size = new System.Drawing.Size(38, 20);
            this.mnu.Text = "Lab";
            // 
            // frm1
            // 
            this.frm1.Name = "frm1";
            this.frm1.Size = new System.Drawing.Size(180, 22);
            this.frm1.Text = "Форма 1";
            this.frm1.Click += new System.EventHandler(this.frm1_Click);
            // 
            // frm2
            // 
            this.frm2.Name = "frm2";
            this.frm2.Size = new System.Drawing.Size(180, 22);
            this.frm2.Text = "Форма 2";
            this.frm2.Click += new System.EventHandler(this.frm2_Click);
            // 
            // ext
            // 
            this.ext.Name = "ext";
            this.ext.Size = new System.Drawing.Size(180, 22);
            this.ext.Text = "Выход";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 223);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnu;
        private System.Windows.Forms.ToolStripMenuItem frm1;
        private System.Windows.Forms.ToolStripMenuItem frm2;
        private System.Windows.Forms.ToolStripMenuItem ext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}

