﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab16
{
    public partial class Form1 : Form
    {
        bool КнопкаНажата;
        bool ИнструментКвадрат;
        bool ИнструментЭллипс;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Graphics myg = this.CreateGraphics();// создаем холст для рисования
            int CursorX = Cursor.Position.X; // координата X курсора мыши
            int CursorY = Cursor.Position.Y; // координата Y курсора мыши
            Color myColor = Color.FromArgb(100, Color.Red);// Задаем цвет
            SolidBrush myb = new SolidBrush(myColor); // переменная инструмента Кисть
            Rectangle myrect = new Rectangle(CursorX, CursorY, 10, 10); // создаем квадратик, связываем его с координатами мыши
            myg.FillRectangle(myb, myrect); // рисуем квадрат кистью на холсте
            if (КнопкаНажата == true)
            {
                myg.FillRectangle(myb, myrect); // рисуем квадрат кистью на холсте
            }
            if (КнопкаНажата == true && ИнструментКвадрат == true)
            {
                myg.FillRectangle(myb, myrect); // рисуем квадрат кистью на холсте
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            КнопкаНажата = true;
            
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            ИнструментКвадрат = true;
            ИнструментЭллипс = false;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            КнопкаНажата = true;
        }
    }
}
