﻿
namespace lab13
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.stroka = new System.Windows.Forms.TextBox();
            this.symbol = new System.Windows.Forms.TextBox();
            this.btnc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // stroka
            // 
            this.stroka.Location = new System.Drawing.Point(378, 113);
            this.stroka.Name = "stroka";
            this.stroka.Size = new System.Drawing.Size(100, 20);
            this.stroka.TabIndex = 0;
            // 
            // symbol
            // 
            this.symbol.Location = new System.Drawing.Point(378, 189);
            this.symbol.Name = "symbol";
            this.symbol.Size = new System.Drawing.Size(100, 20);
            this.symbol.TabIndex = 1;
            // 
            // btnc
            // 
            this.btnc.Location = new System.Drawing.Point(393, 253);
            this.btnc.Name = "btnc";
            this.btnc.Size = new System.Drawing.Size(75, 23);
            this.btnc.TabIndex = 2;
            this.btnc.Text = "Count";
            this.btnc.UseVisualStyleBackColor = true;
            this.btnc.Click += new System.EventHandler(this.btnc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(267, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "введите строку";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(270, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "кол-во букв А";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnc);
            this.Controls.Add(this.symbol);
            this.Controls.Add(this.stroka);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox stroka;
        private System.Windows.Forms.TextBox symbol;
        private System.Windows.Forms.Button btnc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

