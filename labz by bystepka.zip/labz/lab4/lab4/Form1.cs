﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            lstMenu.Items.Add("Пицца");
            lstMenu.Items.Add("Паста");
            lstMenu.Items.Add("Салат");
            lstMenu.Items.Add("Суп");
            lstMenu.Items.Add("Кофе");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lstZakaz.Items.Add(lstMenu.Text);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            lstZakaz.Items.Remove(lstZakaz.SelectedItem);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Приятного аппетита!", "REstoran");
            this.Close();   
        }

        private void lstMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
