﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            lst.Items.Add("black");
            lst.Items.Add("red");
            lst.Items.Add("blue");
            lst.Items.Add("green");
        }
        
       
        private void txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void lst_SelectedIndexChanged(object sender, EventArgs e)
        {
          string Svet = lst.SelectedItem.ToString();
            txt.Text = Svet;
            switch (Svet)
            {
                case "black":
                    txt.BackColor = Color.Black;
                    txt.ForeColor = Color.White;
                    break;
                case "red":
                    txt.BackColor = Color.Red;
                    txt.ForeColor = Color.White;
                    break;
                case "blue":
                    txt.BackColor = Color.DarkBlue;
                    txt.ForeColor = Color.White;
                    break;
                case "green":
                    txt.BackColor = Color.Green;
                    txt.ForeColor = Color.White;
                    break;
                default:
                    txt.BackColor = SystemColors.Window;
                    txt.ForeColor = SystemColors.WindowText;
                    break;
            }
        }

       
    }
}
