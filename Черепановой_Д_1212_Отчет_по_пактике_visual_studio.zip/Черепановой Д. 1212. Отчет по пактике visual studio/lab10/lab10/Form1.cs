﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtArray_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int[] numbers = {66,3,6,88};

            txtOutput.Text = "Массив:\r\n";

            foreach (int num in numbers)
            {
                txtOutput.Text += num.ToString() + "\r\n";
            }

            int sum = 0;
            foreach (int num in numbers)
            {
                sum += num;
            }
            txtOutput.Text += $"\r\nСумма: {sum}\r\n";

            double average = (double)sum / numbers.Length;

            txtOutput.Text += $"Среднее арифметическое: {average:F2}";
        }
    }
}

