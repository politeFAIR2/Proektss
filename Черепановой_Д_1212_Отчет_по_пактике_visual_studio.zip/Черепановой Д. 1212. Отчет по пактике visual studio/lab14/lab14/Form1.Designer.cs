﻿namespace lab14
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtN = new TextBox();
            txtMin = new TextBox();
            txtMax = new TextBox();
            lblArr = new Label();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            lblResult = new Label();
            btnNewArr = new Button();
            btnSort = new Button();
            btnExit = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(159, 102);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(245, 25);
            label1.TabIndex = 0;
            label1.Text = "Количество чисел в массиве";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(159, 157);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(199, 25);
            label2.TabIndex = 1;
            label2.Text = "Нижняя граница чисел";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(159, 212);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(201, 25);
            label3.TabIndex = 2;
            label3.Text = "Верхняя граница чисел";
            // 
            // txtN
            // 
            txtN.Location = new Point(404, 102);
            txtN.Margin = new Padding(4, 5, 4, 5);
            txtN.Name = "txtN";
            txtN.Size = new Size(141, 31);
            txtN.TabIndex = 3;
            // 
            // txtMin
            // 
            txtMin.Location = new Point(404, 157);
            txtMin.Margin = new Padding(4, 5, 4, 5);
            txtMin.Name = "txtMin";
            txtMin.Size = new Size(141, 31);
            txtMin.TabIndex = 4;
            txtMin.TextChanged += txtMin_TextChanged;
            // 
            // txtMax
            // 
            txtMax.Location = new Point(404, 212);
            txtMax.Margin = new Padding(4, 5, 4, 5);
            txtMax.Name = "txtMax";
            txtMax.Size = new Size(141, 31);
            txtMax.TabIndex = 5;
            txtMax.TextChanged += txtMax_TextChanged;
            // 
            // lblArr
            // 
            lblArr.AutoSize = true;
            lblArr.Location = new Point(9, 53);
            lblArr.Margin = new Padding(4, 0, 4, 0);
            lblArr.Name = "lblArr";
            lblArr.Size = new Size(0, 25);
            lblArr.TabIndex = 6;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblArr);
            groupBox1.Location = new Point(159, 357);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(717, 83);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Исходный массив";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblResult);
            groupBox2.Location = new Point(159, 492);
            groupBox2.Margin = new Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 5, 4, 5);
            groupBox2.Size = new Size(717, 83);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Преобразованный массив";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(9, 53);
            lblResult.Margin = new Padding(4, 0, 4, 0);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(0, 25);
            lblResult.TabIndex = 6;
            // 
            // btnNewArr
            // 
            btnNewArr.Location = new Point(191, 665);
            btnNewArr.Margin = new Padding(4, 5, 4, 5);
            btnNewArr.Name = "btnNewArr";
            btnNewArr.Size = new Size(161, 38);
            btnNewArr.TabIndex = 10;
            btnNewArr.Text = "Новый массив";
            btnNewArr.UseVisualStyleBackColor = true;
            btnNewArr.Click += btnNewArr_Click;
            // 
            // btnSort
            // 
            btnSort.Location = new Point(361, 665);
            btnSort.Margin = new Padding(4, 5, 4, 5);
            btnSort.Name = "btnSort";
            btnSort.Size = new Size(150, 38);
            btnSort.TabIndex = 11;
            btnSort.Text = "Сортировать";
            btnSort.UseVisualStyleBackColor = true;
            btnSort.Click += btnSort_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(520, 665);
            btnExit.Margin = new Padding(4, 5, 4, 5);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(151, 38);
            btnExit.TabIndex = 12;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(btnExit);
            Controls.Add(btnSort);
            Controls.Add(btnNewArr);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(txtMax);
            Controls.Add(txtMin);
            Controls.Add(txtN);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Сортировка массива";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtN;
        private TextBox txtMin;
        private TextBox txtMax;
        private Label lblArr;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label lblResult;
        private Button btnNewArr;
        private Button btnSort;
        private Button btnExit;
    }
}
