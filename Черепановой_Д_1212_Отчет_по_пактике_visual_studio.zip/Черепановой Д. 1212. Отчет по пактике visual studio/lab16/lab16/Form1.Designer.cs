﻿namespace lab16
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            инструментыToolStripMenuItem = new ToolStripMenuItem();
            квадратToolStripMenuItem = new ToolStripMenuItem();
            кругToolStripMenuItem = new ToolStripMenuItem();
            colorDialog1 = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { инструментыToolStripMenuItem, colorDialog1 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(9, 3, 0, 3);
            menuStrip1.Size = new Size(1143, 35);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // инструментыToolStripMenuItem
            // 
            инструментыToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { квадратToolStripMenuItem, кругToolStripMenuItem });
            инструментыToolStripMenuItem.Name = "инструментыToolStripMenuItem";
            инструментыToolStripMenuItem.Size = new Size(138, 29);
            инструментыToolStripMenuItem.Text = "Инструменты";
            // 
            // квадратToolStripMenuItem
            // 
            квадратToolStripMenuItem.Name = "квадратToolStripMenuItem";
            квадратToolStripMenuItem.Size = new Size(180, 34);
            квадратToolStripMenuItem.Text = "Квадрат";
            квадратToolStripMenuItem.Click += квадратToolStripMenuItem_Click;
            // 
            // кругToolStripMenuItem
            // 
            кругToolStripMenuItem.Name = "кругToolStripMenuItem";
            кругToolStripMenuItem.Size = new Size(180, 34);
            кругToolStripMenuItem.Text = "Круг";
            // 
            // colorDialog1
            // 
            colorDialog1.Name = "colorDialog1";
            colorDialog1.Size = new Size(67, 29);
            colorDialog1.Text = "Цвет";
            colorDialog1.Click += цветToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Графический редактор";
            Load += Form1_Load;
            MouseDown += Form1_MouseDown;
            MouseMove += Form1_MouseMove;
            MouseUp += Form1_MouseUp;
            Move += Form1_Move;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem инструментыToolStripMenuItem;
        private ToolStripMenuItem квадратToolStripMenuItem;
        private ToolStripMenuItem кругToolStripMenuItem;
        private ToolStripMenuItem colorDialog1;
    }
}
