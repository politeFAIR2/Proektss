﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6
{
    public partial class Секундомер : Form

    {
        private int seconds = 0;
        private int minutes = 0;

        public Секундомер()
        {
            InitializeComponent();
        }

        private void tmrSecundomer_Tick(object sender, EventArgs e)
        {
            seconds++;

            
            if (seconds == 60)
            {
                seconds = 0;
                minutes++;
            }

            
            txtSeconds.Text = seconds.ToString();
            txtMinutes.Text = minutes.ToString();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrSecundomer.Start();
        }

        private void Секундомер_Load(object sender, EventArgs e)
        {

        }
    }
}
