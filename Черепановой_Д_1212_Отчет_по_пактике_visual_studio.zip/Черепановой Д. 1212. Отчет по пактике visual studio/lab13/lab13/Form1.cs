namespace lab13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        public int NumberSymbols(string text, char symbol)
        {
            int count = 0;

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == symbol)
                {
                    count++;
                }
            }

            return count;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            string text = txtInput.Text;
            char symbol = txtSymbol.Text[0];

            int count = NumberSymbols(text, symbol);

            lblOutput.Text = $"���������� �������� '{symbol}' � ������: {count}";
        }
    }
}
