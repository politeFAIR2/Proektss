﻿namespace lab12
{
    partial class frmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            лабараторнаяРаботаToolStripMenuItem = new ToolStripMenuItem();
            Frm1 = new ToolStripMenuItem();
            Frm2 = new ToolStripMenuItem();
            Frm3 = new ToolStripMenuItem();
            выходToolStripMenuItem = new ToolStripMenuItem();
            форма3ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { лабараторнаяРаботаToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(9, 3, 0, 3);
            menuStrip1.Size = new Size(594, 35);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // лабараторнаяРаботаToolStripMenuItem
            // 
            лабараторнаяРаботаToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { Frm1, Frm2, Frm3, выходToolStripMenuItem, форма3ToolStripMenuItem });
            лабараторнаяРаботаToolStripMenuItem.Name = "лабараторнаяРаботаToolStripMenuItem";
            лабараторнаяРаботаToolStripMenuItem.Size = new Size(207, 29);
            лабараторнаяРаботаToolStripMenuItem.Text = "Лабараторная работа";
            лабараторнаяРаботаToolStripMenuItem.Click += лабараторнаяРаботаToolStripMenuItem_Click;
            // 
            // Frm1
            // 
            Frm1.Name = "Frm1";
            Frm1.Size = new Size(186, 34);
            Frm1.Text = "Форма 1";
            Frm1.Click += frm1_Click;
            // 
            // Frm2
            // 
            Frm2.Name = "Frm2";
            Frm2.Size = new Size(186, 34);
            Frm2.Text = "Форма 2";
            Frm2.Click += Frm2_Click;
            // 
            // Frm3
            // 
            Frm3.Name = "Frm3";
            Frm3.Size = new Size(186, 34);
            Frm3.Text = "Форма 3";
            Frm3.Click += Frm3_Click;
            // 
            // выходToolStripMenuItem
            // 
            выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            выходToolStripMenuItem.Size = new Size(186, 34);
            выходToolStripMenuItem.Text = "Выход";
            выходToolStripMenuItem.Click += выходToolStripMenuItem_Click;
            // 
            // форма3ToolStripMenuItem
            // 
            форма3ToolStripMenuItem.Name = "форма3ToolStripMenuItem";
            форма3ToolStripMenuItem.Size = new Size(186, 34);
            форма3ToolStripMenuItem.Text = "Форма 3";
            // 
            // frmMain
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(594, 353);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(4, 5, 4, 5);
            Name = "frmMain";
            Text = "frmMain";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem лабараторнаяРаботаToolStripMenuItem;
        private ToolStripMenuItem Frm1;
        private ToolStripMenuItem Frm2;
        private ToolStripMenuItem Frm3;
        private ToolStripMenuItem выходToolStripMenuItem;
        private ToolStripMenuItem форма3ToolStripMenuItem;
    }
}
